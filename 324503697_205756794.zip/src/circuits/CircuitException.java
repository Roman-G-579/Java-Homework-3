package circuits;

public class CircuitException extends Exception {
    //creates a new exception with a message
    public CircuitException(String msg) {
        super(msg);
    }
}
