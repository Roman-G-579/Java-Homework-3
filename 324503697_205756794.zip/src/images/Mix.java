package images;

public class Mix {
    public Mix(Image circle, Image grad, double v) {
    }
}
