package images;

public abstract class ImageDecorator implements Image{



}
