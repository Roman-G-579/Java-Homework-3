package images;

public abstract class BinaryImageDecorator implements Image{



}
