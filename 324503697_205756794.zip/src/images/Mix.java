package images;

public class Mix extends BinaryImageDecorator {

    private double alpha;
    private Image base1, base2;

    public Mix(Image base1, Image base2, double alpha) {
        super(base1, base2);
        this.alpha = alpha;
        this.base1 = base1;
        this.base2 = base2;
    }


    public RGB get(int x, int y) {
        int base1Height = base1.getHeight();
        int base2Width = base2.getWidth();

        //if the coordinate is inside both images
        if (x <= base2Width && y <= base1Height) {
            return RGB.mix(base1.get(x, y), base2.get(x, y), alpha);
        }

        //if the coordinate is only inside the first image
        if (x > base2Width && y <= base1Height) {
            return base1.get(x, y);
        }

        //if the coordinate is only inside the second image
        if (x <= base2Width) {
            return base2.get(x, y);
        }
        return RGB.BLACK;
    }
}
